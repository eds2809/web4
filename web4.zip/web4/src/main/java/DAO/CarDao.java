package DAO;

import model.Car;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import java.sql.Date;
import java.util.List;

public class CarDao {

    private Session session;

    public CarDao(Session session) {
        this.session = session;
    }

    public List<Car> getAllCars() {
        Transaction transaction = session.beginTransaction();
        List<Car> cars = session.createCriteria(Car.class)
                .add(Restrictions.isNull("dateOfSale"))
                .list();
        transaction.commit();
        session.close();
        return cars;
    }

    public void addCar(Car car) {
        Transaction transaction = session.beginTransaction();
        session.save(car);
        transaction.commit();
        session.close();
    }

    public List<Car> getCarsFromBrand(String brand) {
        List<Car> cars = session.createCriteria(Car.class)
                .add(Restrictions.isNull("dateOfSale"))
                .add(Restrictions.eq("brand", brand))
                .list();
        session.close();
        return cars;
    }

    public List<Car> getAllCarsPriceTotay() {
        List<Car> cars = session.createCriteria(Car.class)
                .add(Restrictions.eq("dateOfSale", new Date(System.currentTimeMillis())))
                .list();
        session.close();
        return cars;
    }

    public void deleteAll() {
        Transaction transaction  = session.beginTransaction();
        Query query = session.createQuery("delete from Car");
        query.executeUpdate();
        transaction.commit();
        session.close();
    }

    public Car getCar(Car carDataSet) {
        Car car = (Car) session.createCriteria(Car.class)
                .add(Restrictions.eq("brand",carDataSet.getBrand()))
                .add(Restrictions.eq("model",carDataSet.getModel()))
                .add(Restrictions.eq("licensePlate",carDataSet.getLicensePlate()))
                .add(Restrictions.isNull("dateOfSale"))
                .setMaxResults(1).uniqueResult();
        session.close();
        return car;
    }

    public void update(Car car) {
        Transaction transaction = session.beginTransaction();
        session.update(car);
        transaction.commit();
        session.close();
    }
}
