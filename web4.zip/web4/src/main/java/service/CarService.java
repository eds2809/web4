package service;

import DAO.CarDao;
import model.Car;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import util.DBHelper;

import java.util.List;

public class CarService {

    private static CarService carService;

    private SessionFactory sessionFactory;

    private CarService(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public static CarService getInstance() {
        if (carService == null) {
            carService = new CarService(DBHelper.getSessionFactory());
        }
        return carService;
    }


    public List<Car> getAllCars() {
        return new CarDao(sessionFactory.openSession()).getAllCars();

    }

    public void addCar(Car car) {
        new CarDao(sessionFactory.openSession()).addCar(car);
    }

    public List<Car> getAllCarsFromBrand(String brand) {
        return new CarDao(sessionFactory.openSession()).getCarsFromBrand(brand);
    }

    public List<Car> getAllCarsPriceToday() {
        return new CarDao(sessionFactory.openSession()).getAllCarsPriceTotay();
    }

    public void deleteAll(){
        new CarDao(sessionFactory.openSession()).deleteAll();
    }

    public Car getCar(Car car) {
        return new CarDao(sessionFactory.openSession()).getCar(car);
    }

    public void update(Car car) {
        new CarDao(sessionFactory.openSession()).update(car);
    }
}
